#include<iostream>
using namespace std;
class node
{
	public:
	int info;
	node*next;
};
class list:public node
{
	public:
	node*first;
	node*last;
	node*temp;
	node*current;
	node*pre;
	node*after;
	list()
	{
		first=NULL;
		last=NULL;
		current=NULL;
		pre=NULL;
		after=NULL;
	}
	int size;
	void create()
	{
		int n;
		cout<<"Enter number of nodes"<<endl;
		cin>>size;
		for(int i=0;i<size;i++)
		{
			cout<<"Enter value for node.."<<endl;
			cin>>n;
		    temp=new node;
		    temp->info=n;
		    temp->next=NULL;
		    if(first==NULL)
		    {
		    	first=last;
				last=temp;
				first=temp;
		     }
		    else
		   {
			 last->next=temp;
			 temp->next=first;
			 last=temp;		
	        }
		}
	}
	void display()
	{
		node*temp=first;
		cout<<"Displaying information"<<endl;
		if(temp==NULL)
		{
			cout<<"list is empty..."<<endl;
		}
		cout<<"NUmber of nodes in  linklist are "<<size<<endl;
		while(temp->next!=first)
		{
			cout<<temp->info<<endl;
			temp=temp->next;
		}
		cout<<temp->info<<endl;
	}
	void insertnode()
	{
		int v,pos,count=1;
		pos:
		cout<<"Enter position where you want to add node"<<endl;
	    cin>>pos;
	    if(pos<1||pos>size)//position must within limit//
	    {
	    	cout<<"Oops!!Incorrect position"<<endl;
	    	cout<<"Please retry"<<endl;
	    	goto pos;
		}
		else
		{
		cout<<"Enter the value in node"<<endl;
		cin>>v;
		temp=new node;
		temp->info=v;
		temp->next=NULL;
	    current=first;
		while(count!=pos)
	    {
	    	pre=current;
	    	current=current->next;
	    	count++;
		}
		if(count==pos && pos!=1)
		{
	    	pre->next=temp;
			temp->next=current;
		}
		else if(count==pos && pos==1)
		{
			temp->next=first;
			first=temp;
			last->next=first;
		}
		else if(count==pos && pos==size)
		{
			current->next=temp;
			temp->next=first;
			
		}
		size++;
	   }
	}
   void deletenode()
	{
		int count=1,pos;
		pos:
		cout<<"Enter node number which node you want to delete node"<<endl;
	    cin>>pos;
	    if(pos<1||pos>size)//position must within limit//
	    {
	    	cout<<"Oops!! Incorrect position"<<endl;
	    	cout<<"Please retry"<<endl;
	    	goto pos;
		}
		current=first;
		while(count!=pos)
		{
			pre=current;
			current=current->next;
			after=current->next;//saving value of node next to current//
			count++;
			}
		if(count==pos && pos!=1 && pos!=size)
		{
			pre->next=current->next;//connecting pre with node next to current//
			current=NULL;
		}
		else if(count==pos && pos==1&& pos!=size)
		{
			first=first->next;//2nd node became 1st//
			current->next=NULL;//1st node deleted//
			current=first;
			last->next=first;
		}
		else if(count==pos &&pos==size&& pos!=1)
		{
			pre->next=first;
			last=pre;
		}
		size--;
	}
};
int main()
{
	list obj;
	int choice,pos,count=1;
	while(choice!=5)
	{
	cout<<"MENU \n1-Create\t\t\t2-Add node\n3-Display list\t\t\t4-Delete node\n5-Exit"<<endl;
	cout<<"Enter choice"<<endl;
	cin>>choice;
	if(choice<1||choice>5)
	{
		cout<<"Invalid input!! Retry"<<endl;
	}
	else
	{
	 switch(choice)
	 {
		case 1:
			obj.create();
			break;
			case 2:
	            obj.insertnode();
				break;
				case 3:
			    	obj.display();
					break;
					case 4:
						obj.deletenode();
						break;

      }
    }
   }
cout<<"Thank you for using our services!!"<<endl;
	return 0;
}

	
