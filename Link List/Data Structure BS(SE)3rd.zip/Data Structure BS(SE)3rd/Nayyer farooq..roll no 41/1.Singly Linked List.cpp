#include<bits/stdc++.h>
using namespace std;

class node
{
	public:
		int info;
		node*next;
};

class singly_linklist:public node
{
	public:
		node *temp,*first,*last;
		int data;
		list()
		{
			first=NULL;
			last=NULL;
		}
		void create();
		void display();
		void adding();
		void deleting();
};

void singly_linklist::create()
{
	int no_nodes;
	cout<<"Enter number of nodes you want to store:";
	cin>>no_nodes;
	for(int i=0;i<no_nodes;i++)
	{
		cout<<"\nEnter value # "<<i+1<<" :";
		cin>>data;
		temp=new node;
		temp->info=data;
		temp->next=NULL;
		if(first==NULL)
		{
			first=temp;
			last=first;
		}
		else
		{
			last->next=temp;
			last=temp;
		}
	}
}

void singly_linklist::display()
{
	temp=first;
	if(temp==NULL)
	{
		cout<<"\nList is empty...";
	}
	while(temp->next!=NULL)
	{
		cout<<"\n==>"<<temp->info;
		temp=temp->next;
		if(temp->next==NULL)
		{
		cout<<"\n==>"<<temp->info;	
		}
	}
}

void singly_linklist::adding()
{
node*previous;
temp=first;
int location;
cout<<"\nEnter location to store node at :";
cin>>location;
if(location==1)
{
	int data;
cout<<"\nEnter the value :";
cin>>data;
node *newNode=new node;
newNode->info=data;
newNode->next=NULL;

newNode->next=first;
first=newNode;
}
else
{
int i=1;
while(i<location)
{
	previous=temp;
	temp=temp->next;
	i++;
}
int data;
cout<<"\nEnter the value :";
cin>>data;
node *newNode=new node;
newNode->info=data;
newNode->next=NULL;


previous->next=newNode;
newNode->next=temp;
}
}

void singly_linklist::deleting()
{
node*previous;
temp=first;
int location;
cout<<"\nEnter location to delete node from :";
cin>>location;
if(location==1)
{
	first=first->next;
}
else
{
int i=1;
while(i<location)
{
	previous=temp;
	temp=temp->next;
	i++;
}


previous->next=temp->next;
cout<<"\nDeleted...";
}
}

int main()
{
	singly_linklist obj;

	cout<<"\t       single link list";
	cout<<"\n-----------------------------------------------------------------------\n";
	cout<<"1:Create\t\t2:Display\n3:Add At Location\t4:Delete From Location\n5:Exit";
	cout<<"\n---------------------------------------------------------------";
	int choice;
	while(choice!=5)
	{
	cout<<"\nEnter Your choice :";
	cin>>choice;
	
	switch(choice)
	{
		case 1:
			obj.create();
			break;
		case 2:
			obj.display();
			break;
		case 3:
			obj.adding();
			break;
		case 4:
			obj.deleting();
			break;
		case 5:
			cout<<"\t  exist...";
			break;	
	}
	}
    return 0;
}
