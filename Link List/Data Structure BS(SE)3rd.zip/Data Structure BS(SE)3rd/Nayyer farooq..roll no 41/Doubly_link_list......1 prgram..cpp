#include<bits/stdc++.h>
using namespace std ;
class node
{
	public:
	int data;
	node*next;
	node*pre;
};
class singlylinklist
{
	public:
		
		public:
		int size,i,n;
		node*first,*last,*temp,*cur,*previous;
		singlylinklist()
		{
			first=NULL;
			last=NULL;
		}
		void create();
		void display();
		void add_at_any_pos();
		void delete_at_any_pos();
	};
	void singlylinklist::create()
	{
	        	cout<<"Enter the number of nodes you want: ";
			cin>>size;
			cout<<"\n";
			for(i=0;i<size;i++)
			{
				cout<<"Enter the value:> ";
				cin>>n;
				temp=new node;
				temp->data=n;
				temp->pre=NULL;
				temp->next=NULL;
				if(first==NULL)
				{
					first=temp;
					last=first;
				}
				else
				{
					temp->pre=last;
					last->next=temp;
					last=temp;
				}
			}
    }
    
    void singlylinklist::add_at_any_pos()
    {
    	node*pre;
    		size++;
		    int count=1;
		    cur=first;
			int pos;
			cout<<"\nEnter location where you want to add node: ";
			cin>>pos;
            while(count!=pos)
			{
				previous=cur;
				cur=cur->next;
				count++;
		    }  
			if(pos==1)
			{
			    int n;
		        temp=new node;
			    cout<<"\nEnter Value for first node: ";
			    cin>>n;
		      	temp->data=n;
		      	temp->pre=NULL;
		      	temp->next=NULL;
	           	temp->next=first;
	           	first->pre=temp;
		        first=temp;
			}   	
		    else if(pos==size)
            {
			  	int a;
		       	temp=new node;
		   	    cout<<"Enter value for last node: ";
		        cin>>n;
		        temp->data=n;
		        temp->next=NULL;
		        last->next=temp;
		        temp->pre=last;
		        last=temp;
       		}
		    else if (count==pos)
			{
        		temp=new node;
			    cout<<"Enter value for node;";
			    cin>>n;
			    temp->data=n;
				temp->next=NULL;
				previous->next=temp;
				
				temp->pre=previous;
				temp->next=cur;
				cur->pre=temp;
			}
    	
	}
    
    void singlylinklist::delete_at_any_pos()
    {
    	
    		int count=1;
		    cur=first;
		    node*previous;
			int pos;
			cout<<"\nEnter the location of node that you want to del: ";
			cin>>pos;
	        while(count!=pos)
			{
			    cur=cur;
				cur=cur->next;
				count++;
			} 
			if(pos==1)
			{ 
			    cout<<endl;
			    temp=first;
			    temp=temp->next;
			    temp->pre=NULL;
			    first=temp; 
		    }
		    else if(pos==size)
		    {
		    	temp=last;
			    temp=temp->pre;
			    temp->next=NULL;
			    last=temp;
			}
			else if(count==pos)
			{
				cur=cur->next;
			    previous->next=cur;
			    cur->pre=previous;
				cur=NULL;
			}		
    	
    }
    
    void singlylinklist::display()
    {
    	cout<<"............Values for Doubly_link_list node........"<<endl;
    	temp=first;
			cout<<"\nNodes in ascending order: ";
			while(temp!=NULL)
			{
				cout<<temp->data<<"\t";
				temp=temp->next;
			}
			temp=last;
			cout<<"\nNodes in descending order: ";
			while(temp!=NULL)
			{
				cout<<temp->data<<"\t";
				temp=temp->pre;
			}
    	
	}


int main()
{

	singlylinklist obj;
	cout<<"\n==================Doubly-link-list Menu=======================";
	 cout<<"\n1:CREATE\t\t2:ADD NODES\t\t3:DELETE NODES\t\t4:DISPLAY\t\t5:EXIT\n";
	cout<<"\n==========================================";
	int ch;
	while(1)
	{
	cout<<"\nPlease enter your choice..";
	        cin>>ch;
	        switch(ch)
	        {
	        	
        case 1:
            obj.create();
            break;
        case 2:
            obj.add_at_any_pos();
            break;
        case 3:
            obj.delete_at_any_pos();
            break;
        case 4:
            obj.display();
            break;
        case 5:
            return 0;
       }
	   
	   }
	             
}

