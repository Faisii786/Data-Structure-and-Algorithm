#include<iostream>
using namespace std;
class node
{
	public:
	node *temp,*pre,*next; 
	int info;
};
class list
{
	public:
	int info;
	node*next;
	node*first;
	node*last;
	node*pre;
	node*ptr;
	node*tail;
	node*temp;
	node*current;
	node*previous;
	node*after;
		list()
		{
			first=NULL;
			last=NULL;
			current=NULL;
			previous=NULL;
			tail=NULL;
			after=NULL;
		}
	int size;
		void create()
		{
			int n;
			cout<<"Enter no. of nodes you want:"<<endl;
			cin>>size;
			for(int i=1;i<=size;i++)
			{
				cout<<"Enter value for node:"<<endl;
				cin>>n;
			    temp=new node;
			    temp->info=n;
			    temp->pre=NULL;
			    temp->next=NULL;
			    if(first==NULL)
			    {
				first=temp;
				last=first;
				tail=first;
			    }
			    else
			    {
			     last->next=temp;
			     temp->pre=last;
			     last=temp;	
				 tail=temp;	
		       }
			}
		}
		void displayforward()
		{
			node*ptr=first;
			if(ptr==NULL)
			{
				cout<<"list is empty!"<<endl;
			}
			while(ptr!=NULL)
			{
				cout<<ptr->info<<"-->";
				ptr=ptr->next;
			}
		}
		void displaybackward()
		{
			node*ptr=tail;
			if(ptr==NULL)
			{
				cout<<"list is empty!"<<endl;
			}
			while(ptr!=NULL)
			{
				cout<<ptr->info<<"-->";
				ptr=ptr->pre;
			}
		}
		void insertnode()
	{
		int v,pos,count=1;
		cout<<"Enter position where you want to add node:"<<endl;
	    cin>>pos;
		{
		cout<<"Enter the value in node:"<<endl;
		cin>>v;
		temp=new node;
		temp->info=v;
		temp->next=NULL;
		temp->pre=NULL;
	    current=first;
		while(count!=pos)
	    {
	    	previous=current;
	    	current=current->next;
	    	count++;
		}
		if(count==pos && pos!=1 && pos!=size)
		{
	    	previous->next=temp;
	    	temp->pre=previous;
			temp->next=current;
			current->pre=temp;
		}
		else if(count==pos && pos==1)
		{
			first->pre=temp;
			temp->next=first;
			temp->pre=NULL;
			first=temp;
		}
		else if(count==pos && pos==size)
		{
			last->next=temp;
			temp->pre=last;
			temp->next=NULL;
			last=temp;
			tail=temp;
		}
		size++;
	   }
	}
   void deletenode()
	{
		int count=1,pos;
		cout<<"Enter which node you want to delete:"<<endl;
	    cin>>pos;
		current=first;
		while(count!=pos)
		{
			previous=current;
			current=current->next;
			after=current->next;//saving value of node next to current//
			count++;
			}
		if(count==pos && pos!=1 && pos!=size)
		{
			current->next=NULL;
			current->pre=NULL;
			previous->next=after;//connecting previous with node next to current//
			after->pre=previous;
		}
		else if(count==pos && pos==1)
		{
			first=first->next;//2nd node became 1st//
			first->pre=NULL;
			current->next=NULL;//1st node deleted//
			current->pre=NULL;
			current=first;
		}
		else if(count==pos && pos==size)
		{
			previous->next=NULL;
			last->pre=NULL;
			last=previous;
			tail=last;
		}
		size--;
	}
};
int main()
{
	list obj;
	int choice;


	cout<<"1-Create\n2-Add node at any position\n3-Display list forward\n4-Display list backwardly\n5-Delete node at any position\n6-Exit"<<endl;

	while(choice!=6)
{
	cout<<"\nEnter choice"<<endl;
	cin>>choice;
	 switch(choice)
	 {
		case 1:
			obj.create();
			break;
			case 2:
	            obj.insertnode();
				break;
				case 3:
			    	obj.displayforward();
					break;
					case 4:
						obj.displaybackward();
						break;
						case 5:
							obj.deletenode();
							break;
							case 6:
								cout<<"\t\t\t***Programme Finished***";
								break;;
    }
}

	return 0;
}


