#include <iostream>
#include <stdio.h>
#include <conio.h>

using namespace std;

class node
{
	public:
	int info;
	node *next;	
};
class list:public node
{
	public:
	node *temp,*first,*last,*pre,*current;
	int size,value,count=1;
	
	list()
	{
		first=NULL;
		last=NULL;
	}
	
	void create()
	{
		cout<<"Enter No. of nodes you want?"<<endl;
		cin>>size;
		for(int i=0;i<size;i++)
		{
			temp=new node;
			cout<<"Enter Value:"<<endl;
			cin>>value;
			temp->info=value;
			temp->next=NULL;
			if(first==NULL)
			{
				first=temp;
				last=first;
			}
			else
			{
				last->next=temp;
				last=temp;
			}
		}
	}

	void addatpos()
	{
		node *add;
		int pos,n;
		current=first;
		
		cout<<"\nEnter position where you want to add Node:"<<endl;
		cin>>pos;
		
		add=new node;
		cout<<"\nEnter Value of new node:"<<endl;
		cin>>n;
		add->info=n;
		add->next=NULL;
		while(count!=pos)
		{
			pre=current;
			current=current->next;
			count++;
		}
		if(count==pos)
		{
			pre->next=add;
			add->next=current;
		}

	}
	void deleteatpos()
	{
		current=first;
		int count=1;
		
		int pos;
		cout<<"\nEnter the node you want to delete:"<<endl;
		cin>>pos;
		
		while(count!=pos)
		{
			pre=current;
			current=current->next;
			count++;
		}
		if(count==pos)
		{
			pre->next=NULL;
			current=current->next;
			pre->next=current;
		}
	}
	void display()
	{
		temp=first;
		if(temp==NULL)
		{
			cout<<"List is Empty!"<<endl;
		}
		while(temp!=NULL)
		{
			cout<<temp->info<<"-->";
			temp=temp->next;
		}
	}	
};
int main(int argc, char** argv) 
{
	list obj;
	
	int ch;
	cout<<"1-Create\n2-Display\n3-Add At Any Position\n4-Delete At Any Position\n5-Exit\n";

	while(ch!=5)
{
	cout<<"\nEnter Choice:\n";
	cin>>ch;
	switch(ch)
	{
	case 1:
	{
	obj.create();
	break;
	}
	case 2:
	{	
	obj.display();
	break;
	}
	case 3:
	{
	obj.addatpos();
	break;
	}
	case 4:
	{
	obj.deleteatpos();
	break;
	}
	case 5:
	{
		cout<<"\t\t\t***Programme Finished***";
		break;
	}
	}
}
	return 0;
}
