#include<iostream>
using namespace std;
class Node
{
	public:
	int data;
	Node*next;
	Node*first;
	Node*last;
	Node*temp;
	Node*current;
	Node*pre;
	Node*tail;
	Node*previous;
	Node()
	{
		first=NULL;
		last=NULL;
		current=NULL;
		pre=NULL;
		tail=NULL;
	}
     int size;
		void create()
		{
			int v;
			cout<<"Enter size of nodes"<<endl;
			cin>>size;
			for(int i=0;i<size;i++)
			{
				cout<<"Enter the  value in node of double linklist"<<endl;
				cin>>v;
			    temp=new Node;
			    temp->data=v;
			    temp->pre=NULL;
			    temp->next=NULL;
			    if(first==NULL)
			    {
				first=temp;
				last=first;
				tail=first;
			    }
			    else
			       {
				     last->next=temp;
				     temp->pre=last;
				     last=temp;	
					 tail=temp;	
			       }
			}
		}
		void displayf()
		{
			Node*ptr=first;
			cout<<" displaying the information Forward"<<endl;
			while(ptr!=NULL)
			{
				cout<<ptr->data<<endl;
				ptr=ptr->next;
			}
		}
		void displayb()
		{
			Node*ptr=tail;
			cout<<"displaying the Backward information "<<endl;
			while(ptr!=NULL)
			{
				cout<<ptr->data<<endl;
				ptr=ptr->pre;
			}
		}
	void addnode()
	{
		int n,pos,count=1;
		cout<<"Enter position where you want to add node"<<endl;
	    cin>>pos;
		cout<<"Enter the value for node"<<endl;
		cin>>n;
		temp=new Node;
		temp->data=n;
		temp->next=NULL;
		temp->pre=NULL;
	    current=first;
		while(count!=pos)
	    {
	    	previous=current;
	    	current=current->next;
	    	count++;
		}
		if(count==pos &&pos!=1)
		{
	    	previous->next=temp;
	    	temp->pre=previous;
			temp->next=current;
			current->pre=temp;
		}
		else if(count==pos && pos==1)
		{
			first->pre=temp;
			temp->next=first;
			temp->pre=NULL;
			first=temp;
		}
		else if(count==pos && pos==size)
		{
			last->next=temp;
			temp->pre=last;
			temp->next=NULL;
			last=temp;
			tail=temp;
		}
		else
		{
			cout<<"Unable to insert node"<<endl;
		}
	}
   void deletenode()
	{
		int count=1,pos;
		cout<<"Enter number of node which you want to delete"<<endl;
	    cin>>pos;
		current=first;
		while(count!=pos)
		{
			previous=current;
			current=current->next;
			count++;
			}
		if(count==pos && pos==1)
		{
			first=first->next;
			first->pre=NULL;
			current->next=NULL;
			current->pre=NULL;
			current=first;
		}
		else if(count==pos && pos!=1 &&pos!=size)
		{
			previous->next=current->next;
			current=current->next;
			current->pre=previous;
		}
		else if(count==pos && pos==size)
		{
			previous->next=NULL;
			current->pre=NULL;
			last=previous;
			tail=last;
		}
	}
};
int main()
{
	Node N;
	int ch;
	cout<<"1-Create\n2-Display linklist forward\n3-Display linklist backward\n4-Add node\n5-Delete node\n6-Exit"<<endl;
	while(ch!=6)
	{
	cout<<"Enter choice in integers(from 1 to 6)"<<endl;
	cin>>ch;
	switch(ch)
	{
		case 1:
			N.create();
			break;
			case 2:
				N.displayf();
				break;
				case 3:
					N.displayb();
					break;
					case 4:
				    	N.addnode();
						break;
						case 5:
							N.deletenode();
							break;
	}
}
	return 0;
}


