#include<iostream>
using namespace std;

class node
{
	public:
		int info;
		node*next;
};

class list:public node
{
	public:
		node *temp,*first,*last;
		int data;
		list()
		{
			first=NULL;
			last=NULL;
		}
		void create();
		void display();
		void addAtloc();
		void delFromloc();
};

void list::create()
{
	int no_nodes;
	cout<<"Enter number of nodes you want to store:";
	cin>>no_nodes;
	for(int i=0;i<no_nodes;i++)
	{
		cout<<"\nEnter value # "<<i+1<<" :";
		cin>>data;
		temp=new node;
		temp->info=data;
		temp->next=NULL;
		if(first==NULL)
		{
			first=temp;
			last=first;
		}
		else
		{
			last->next=temp;
			last=temp;
			last->next=first;
		}
	}
}

void list::display()
{
	temp=first;
	if(temp==NULL)
	{
		cout<<"\nList is empty...";
	}
	while(temp->next!=first)
	{
		cout<<"\n==>"<<temp->info;
		temp=temp->next;
		if(temp->next==first)
		{
		cout<<"\n==>"<<temp->info;	
		}
	}
}

void list::addAtloc()
{
node*previous;
temp=first;
int location;
cout<<"\nEnter location to store node at :";
cin>>location;
if(location==1)
{
	int data;
cout<<"\nEnter the value :";
cin>>data;
node *newNode=new node;
newNode->info=data;
newNode->next=NULL;
//SWITCHING
newNode->next=first;
first=newNode;
}
else
{
int i=1;
while(i<location)
{
	previous=temp;
	temp=temp->next;
	i++;
}
int data;
cout<<"\nEnter the value :";
cin>>data;
node *newNode=new node;
newNode->info=data;
newNode->next=NULL;

//INSERTING
previous->next=newNode;
newNode->next=temp;
}
}

void list::delFromloc()
{
node*previous;
temp=first;
int location;
cout<<"\nEnter location to delete node from :";
cin>>location;
if(location==1)
{
	first=first->next;
	last->next=first;
}
else
{
int i=1;
while(i<location)
{
	previous=temp;
	temp=temp->next;
	i++;
}

//DELETING
previous->next=temp->next;
cout<<"\nDeleted...";
}
}

int main()
{
	list obj;
	cout<<"==============================================\n";
	cout<<"\t     CIRCULARLY LINKED LIST";
	cout<<"\n==============================================\n";
	cout<<"1:Create\t\t2:Display\n3:Add At Location\t4:Delete From Location\n5:Exit";
	cout<<"\n==============================================";
	int choice;
	while(choice!=5)
	{
	cout<<"\nEnter Your choice :";
	cin>>choice;
	
	switch(choice)
	{
		case 1:
			obj.create();
			break;
		case 2:
			obj.display();
			break;
		case 3:

			obj.addAtloc();
			break;
		case 4:
			obj.delFromloc();
			break;
		case 5:
			cout<<"\t   Programme Finished...";
			break;	
	}
	}
    return 0;
}
