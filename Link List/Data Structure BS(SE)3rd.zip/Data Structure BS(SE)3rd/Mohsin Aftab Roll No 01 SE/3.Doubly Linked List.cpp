#include<iostream>
using namespace std;
int size;
class node
{
	public:
		int info;
		node*previous;
		node*next;
};

class list:public node
{
	public:
	node *next,*first,*last,*temp,*previous,*current,*tail;
		int data;
		list()
		{
			first=NULL;
			last=NULL;
		}
		void create();
		void display();
		void addAtloc();
		void delFromloc();
};

void list::create()
{
	int no_nodes;
	cout<<"Enter number of nodes you want to store:";
	cin>>no_nodes;
	size=no_nodes;
	for(int i=0;i<no_nodes;i++)
	{
		cout<<"\nEnter value # "<<i+1<<" :";
		cin>>data;
		temp=new node;
		temp->info=data;
		temp->previous=NULL;
		temp->next=NULL;
		if(first==NULL)
		{
			first=temp;
			last=first;
		}
		else
		{
			last->next=temp;
			temp->previous=last;
			last=temp;
		}
	}
}

void list::display()
{
	cout<<"\nDISPLAYING FORWARD :";
	temp=first;
	if(temp==NULL)
	{
		cout<<"\nList is empty...";
	}
	while(temp->next!=NULL)
	{
		cout<<"\n==>"<<temp->info;
		temp=temp->next;
		if(temp->next==NULL)
		{
		cout<<"\n==>"<<temp->info;	
		}
	}
	
	
	cout<<"\nDISPLAYING REVERSE :";
	temp=last;
	if(temp==NULL)
	{
		cout<<"\nList is empty...";
	}
	while(temp->previous!=NULL)
	{
		cout<<"\n==>"<<temp->info;
		temp=temp->previous;
		if(temp->previous==NULL)
		{
		cout<<"\n==>"<<temp->info;	
		}
	}
}
 void list::addAtloc()
    {
    	int n,position,count=1;
		cout<<"Enter the position to add node at :";
	    cin>>position;
		cout<<"Enter the value for the node :";
		cin>>n;
		temp=new node;
		temp->info=n;
		temp->next=NULL;
		temp->previous=NULL;
	    current=first;
		while(count!=position)
	    {
	    	previous=current;
	    	current=current->next;
	    	count++;
		}
		if(count==position &&position!=1)
		{
	    	previous->next=temp;
	    	temp->previous=previous;
			temp->next=current;
			current->previous=temp;
		}
		else if(count==position && position==1)
		{
			first->previous=temp;
			temp->next=first;
			temp->previous=NULL;
			first=temp;
		}
		else if(count==position && position==size)
		{
			last->next=temp;
			temp->previous=last;
			temp->next=NULL;
			last=temp;
			tail=temp;
		}
		else
		{
			cout<<"Unable to add node...";
		}
	}
    
void list::delFromloc()
    {
    int count=1,position;
		cout<<"Enter location to delete node from :";
	    cin>>position;
		current=first;
		while(count!=position)
		{
			previous=current;
			current=current->next;
			count++;
			}
		if(count==position && position==1)
		{
			first=first->next;
			first->previous=NULL;
			current->next=NULL;
			current->previous=NULL;
			current=first;
		}
		else if(count==position && position!=1 &&position!=size)
		{
			previous->next=current->next;
			current=current->next;
			current->previous=previous;
		}
		else if(count==position && position==size)
		{
			previous->next=NULL;
			current->previous=NULL;
			last=previous;
			tail=last;
		}
	}
int main()
{
	list obj;
	cout<<"==============================================\n";
	cout<<"\t       DOUBLY LINKED LIST";
	cout<<"\n==============================================\n";
	cout<<"1:Create\t\t2:Display\n3:Add At Location\t4:Delete From Location\n5:Exit";
	cout<<"\n==============================================";
	int choice;
	while(choice!=5)
	{
	cout<<"\nEnter Your choice :";
	cin>>choice;
	
	switch(choice)
	{
		case 1:
			obj.create();
			break;
		case 2:
			obj.display();
			break;
		case 3:
			obj.addAtloc();
			break;
		case 4:
			obj.delFromloc();
			break;
		case 5:
			cout<<"\t   Programme Finished...";
			break;	
	}
	}
    return 0;
}
