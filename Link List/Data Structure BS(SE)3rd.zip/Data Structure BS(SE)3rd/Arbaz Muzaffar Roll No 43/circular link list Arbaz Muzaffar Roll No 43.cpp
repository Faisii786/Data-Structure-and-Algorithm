#include<iostream>
using namespace std;
class cnode
{
	public:
	int info;
	cnode*first,*last,*next,*temp,*current,*previous;
	cnode()
	{
		first=NULL;
		last=NULL;
		current=NULL;
		previous=NULL;
	}
	int size;
   void create()
		{
			int numnode;
			cout<<"Enter the size of the linklist"<<endl;
			cin>>size;
			for(int i=0;i<size;i++)
			{
				cout<<"Enter the value"<<endl;
				cin>>numnode;
			    temp=new cnode;
			    temp->info=numnode;
			    temp->next=NULL;
			    if(first==NULL)
			    {
				first=last;
				last=temp;
				first=temp;
			    }
			    else
				{
					last->next=temp;
					temp->next=first;
					last=temp;
				}
			}
		}
		void display()
		{
			temp=first;
			cout<<"Information in linklist"<<endl;
			if(temp==NULL)
			{
				cout<<"list is empty"<<endl;
			}
			while(temp->next!=first)
			{
				cout<<temp->info<<endl;
				temp=temp->next;
			}
			cout<<temp->info<<endl;
		}
	void insertnode()
	{
		int x,position,count=1;
		cout<<"Enter the position of adding the node:"<<endl;
	    cin>>position;
		cout<<"Enter the value for node:"<<endl;
		cin>>x;
		temp=new cnode;
		temp->info=x;
		temp->next=NULL;
	    current=first;
		while(count!=position)
	    {
	    	previous=current;
	    	current=current->next;
	    	count++;
		}
		if(count==position && position!=1)
		{
	    	previous->next=temp;
			temp->next=current;
		}
		else if(count==position && position==1)
		{
			temp->next=first;
			first=temp;
			last->next=first;
		}
		else if(count==position && position==size)
		{
			current->next=temp;
			temp->next=first;
		}
		else
		{
			cout<<"we are unable  to add node"<<endl;
		}
	   }
   void deletenode()
	{
		int count=1,position;
		cout<<"Enter the node number which  you want to delete from the list"<<endl;
	    cin>>position;
		current=first;
		while(count!=position)
		{
			previous=current;
			current=current->next;
			count++;
			}
		if(count==position && position!=1)
		{
			previous->next=current->next;
			current=NULL;
		}
		else if(count==position && position==1)
		{
			first=first->next;
			current->next=NULL;
			current=first;
			last->next=first;
		}
		else if(count==position &&position==size)
		{
			previous->next=first;
			last=previous;
		}
    }
};
int main()
{
	cnode obj;
	int choice;
	cout<<"1-Create\t2-Display \n3-Add node\t4-Delete node\n5-Exit"<<endl;
	while(choice!=5)
	{
	cout<<"Enter your choice(1-5)"<<endl;
	cin>>choice;
	switch(choice)
	{
		case 1:
			obj.create();
			break;
			case 2:
				obj.display();
				break;
				case 3:
					obj.insertnode();
					break;
					case 4:
				    	obj.deletenode();
						break;
	}
}
	return 0;
}


