#include<iostream>
using namespace std;
class dnode
{
	public:
	int info;
	dnode*next,*first,*last,*temp,*previous,*current,*tail;

	dnode()
	{
		first=NULL;
		last=NULL;
		current=NULL;
		previous=NULL;
		tail=NULL;
	}
     int size;
		void create()
		{
			int value;
			cout<<"Enter the size of the nodes:"<<endl;
			cin>>size;
			for(int i=0;i<size;i++)
			{
				cout<<"Enter value in node"<<endl;
				cin>>value;
			    temp=new dnode;
			    temp->info=value;
			    temp->previous=NULL;
			    temp->next=NULL;
			    if(first==NULL)
			    {
				first=temp;
				last=first;
				tail=first;
			    }
			    else
			       {
				     last->next=temp;
				     temp->previous=last;
				     last=temp;	
					 tail=temp;	
			       }
			}
		}
		void displayf()
		{
			dnode*ptr=first;
			cout<<"Forward information"<<endl;
			while(ptr!=NULL)
			{
				cout<<ptr->info<<endl;
				ptr=ptr->next;
			}
		}
		void displayb()
		{
			dnode*ptr=tail;
			cout<<"Backward information "<<endl;
			while(ptr!=NULL)
			{
				cout<<ptr->info<<endl;
				ptr=ptr->previous;
			}
		}
	void insertnode()
	{
		int n,pos,count=1;
		cout<<"Enter the position to add node:"<<endl;
	    cin>>pos;
		cout<<"Enter the value for the node"<<endl;
		cin>>n;
		temp=new dnode;
		temp->info=n;
		temp->next=NULL;
		temp->previous=NULL;
	    current=first;
		while(count!=pos)
	    {
	    	previous=current;
	    	current=current->next;
	    	count++;
		}
		if(count==pos &&pos!=1)
		{
	    	previous->next=temp;
	    	temp->previous=previous;
			temp->next=current;
			current->previous=temp;
		}
		else if(count==pos && pos==1)
		{
			first->previous=temp;
			temp->next=first;
			temp->previous=NULL;
			first=temp;
		}
		else if(count==pos && pos==size)
		{
			last->next=temp;
			temp->previous=last;
			temp->next=NULL;
			last=temp;
			tail=temp;
		}
		else
		{
			cout<<"Unable to add node"<<endl;
		}
	}
   void deletenode()
	{
		int count=1,pos;
		cout<<"Enter number which node you want to delete"<<endl;
	    cin>>pos;
		current=first;
		while(count!=pos)
		{
			previous=current;
			current=current->next;
			count++;
			}
		if(count==pos && pos==1)
		{
			first=first->next;
			first->previous=NULL;
			current->next=NULL;
			current->previous=NULL;
			current=first;
		}
		else if(count==pos && pos!=1 &&pos!=size)
		{
			previous->next=current->next;
			current=current->next;
			current->previous=previous;
		}
		else if(count==pos && pos==size)
		{
			previous->next=NULL;
			current->previous=NULL;
			last=previous;
			tail=last;
		}
	}
};
int main()
{
	dnode N;
	int ch;
	cout<<"1-Create\t2-Display linklist forward\n3-Display linklist backward\t4-Add node\n5-Delete node\n6-Exit"<<endl;
	while(ch!=6)
	{
	cout<<"Enter your choice(1-5)"<<endl;
	cin>>ch;
	switch(ch)
	{
		case 1:
			N.create();
			break;
			case 2:
				N.displayf();
				break;
				case 3:
					N.displayb();
					break;
					case 4:
				    	N.insertnode();
						break;
						case 5:
							N.deletenode();
							break;
	}
}
	return 0;
}


