#include<bits/stdc++.h>
using namespace std;

class Node{
  public:
  int data;
  Node *next;
};
class c_list:public Node{
  public:
  Node *first,*last;
  c_list(){
      first=NULL;
      last=NULL;
  }
  public:
  void create();
  void insert();
  void remove_node();
  void dislay();
};
void c_list::create(){
	int nodes;
    cout<<"Enter how many nodes u want"<<endl;
    cin>>nodes;
    for(int i=0; i<nodes; i++){
        int n;
        cout<<"Enter values of node"<<endl;
        cin>>n;
        Node *temp=new Node;
        temp->data=n;
        temp->next=NULL;
        if(first==NULL){
            first=temp;
            last=first;
        }
        else{
            last->next=temp;
            last=temp;
            last->next=first;
        }
    }
}
void c_list::dislay(){
    Node *temp=first;
    if(first!=NULL){
    	cout<<"List contains: ";
        while(true){
            cout<<temp->data<<"-->";
            temp=temp->next;
            if(temp==first)
            break;
        }
    }
}

void c_list::insert(){
	int position,val;
	cout<<endl<<"Enter position where you want to insert node"<<endl;
	cin>>position;
	cout<<endl<<"Enter value of node to be addded"<<endl;
	cin>>val;
	Node* newNode = new Node(); 
      newNode->data = val;
      newNode->next = NULL;
      Node* temp = first;
      int NoOfElements = 0;

      if(temp != NULL) {
        NoOfElements++;
        temp = temp->next;
      }
      while(temp != first) {
        NoOfElements++;
        temp = temp->next;
      }

      if(position < 1 || position > (NoOfElements+1)) {
        cout<<"\nInavalid position.";
      } else if (position == 1) {
      
        if(first == NULL) {
          first = newNode;
          first->next = first;
        } else {
          while(temp->next != first) {
            temp = temp->next;
          }
          newNode->next = first;
          first = newNode;
          temp->next = first;
        }
      } else {
        temp = first;
        for(int i = 1; i < position-1; i++) 
          temp = temp->next;
        newNode->next = temp->next;
        temp->next = newNode;  
      }

}

void c_list::remove_node(){
	int position;
	cout<<endl<<"Enter the position of node to be removed"<<endl;
	cin>>position;
	      Node* nodeToDelete = first; 
      Node* temp = first;
      int NoOfElements = 0;

      if(temp != NULL) {
        NoOfElements++;
        temp = temp->next;
      }
      while(temp != first) {
        NoOfElements++;
        temp = temp->next;
      }

      if(position < 1 || position > NoOfElements) {
        cout<<"\nInavalid position.";
      } else if (position == 1) {
        if(first->next == first) {
          first = NULL;
        } else {     
          while(temp->next != first)
            temp = temp->next;
          first = first->next;
          temp->next = first; 
          free(nodeToDelete); 
        }
      } else {

        temp = first;
        for(int i = 1; i < position-1; i++)
          temp = temp->next;
        nodeToDelete = temp->next;
        temp->next = temp->next->next;
        free(nodeToDelete); 
      }

}

int main(){
	c_list l1;
	l1.create();
	l1.dislay();
	l1.insert();
	l1.dislay();
	l1.remove_node();
	l1.dislay();
	return 0;
}
