#include<bits/stdc++.h>

using namespace std;
class Node
{
public:
    int info;
    Node* next;
};
class List:public Node
{

    Node *first,*last;
public:
    List()
    {
        first=NULL;
        last=NULL;
    }
    void create();
    void insert();
    void remove_node();
    void display();
   
};
void List::create()
{
    int numnode;
    cout<<"Enter number for node you want=";cin>>numnode;
    for(int ii=1;ii<=numnode;ii++){
    Node *temp;
    temp=new Node;
    int n;
    cout<<"\nEnter an Element:";
    cin>>n;
    temp->info=n;
    temp->next=NULL;
    if(first==NULL)
    {
        first=temp;
        last=first;
    }

    else
    {
        last->next=temp;
        last=temp;
    }
    }
}
void List::insert(){
	int position, val;
	cout<<endl<<"Enter position where you want to insert node"<<endl;
	cin>>position;
	cout<<"Enter value of node"<<endl;
	cin>>val;
	      Node* newNode = new Node(); 
      newNode->info = val;
      newNode->next = NULL;

      if(position < 1) {
        cout<<"\nposition should be >= 1.";
      } else if (position == 1) {
        newNode->next = first;
        first = newNode;
      } else {
        
        Node* temp = first;
        for(int i = 1; i < position-1; i++) {
          if(temp != NULL) {
            temp = temp->next;
          }
        }
     
        if(temp != NULL) {
          newNode->next = temp->next;
          temp->next = newNode;  
        } else {
          cout<<"\nThe previous node is null.";
        }       
      }

}

void List::remove_node(){
	int position;
	
	cout<<endl<<"Enter the position of node to be removed"<<endl;
	cin>>position;
	if(position < 1) {
        cout<<"\nposition should be >= 1.";
      } else if (position == 1 && first != NULL) { 
        Node* nodeToDelete = first;
        first = first->next;
        free(nodeToDelete);
      } else {
        Node* temp = first;
        for(int i = 1; i < position-1; i++) {
          if(temp != NULL) {
            temp = temp->next;
          }
        }
        if(temp != NULL && temp->next != NULL) {
            Node* nodeToDelete = temp->next;
            temp->next = temp->next->next;
            free(nodeToDelete); 
        } else {
          cout<<"\nThe node is already null.";
        }       
      }

}
void List::display()
{
    Node *temp=first;
    if(temp==NULL)
    {
        cout<<"\nList is Empty";
    }
    while(temp!=NULL)
    {
        cout<<temp->info;
        cout<<"-->";
        temp=temp->next;
    }
    cout<<"NULL";
}

int main()
{
    List l;
   
   
        l.create();
        l.display();
          l.insert();
          l.display();
          l.remove_node();
          l.display();
}
