#include<bits/stdc++.h>
using namespace std; 

class Node{
	public:
	int data;
	Node *next;
	Node *pre;
};

class doubly_list:public Node{
	public:
	Node *head,*first,*tail,*ptr;
	doubly_list(){
		head=NULL;
		first=NULL;
		tail=NULL;
	}
	void create();
	void insert();
	void remove_node();
	void dislay();
	void displayr();
	
};

void doubly_list::create(){
	int nodes,n;
	cout<<"Enter how many nodes you want"<<endl;
	cin>>nodes;
	for(int i=0; i<nodes; i++){
		cout<<"Enter elements of node"<<endl;
		cin>>n;
		Node *temp=new Node;
		temp->data=n;
		temp->next=NULL;
		temp->pre=NULL;
		if(head==NULL){
			head=temp;
			first=head;
			tail=head;
		}
		else{
			first->next=temp;
			temp->pre=first;
			first=temp;
			tail=temp;
		}
	}
}

void doubly_list::insert(){
	int position,val;
	cout<<endl<<"Enter position where you want to insert node"<<endl;
	cin>>position;
	cout<<endl<<"Enter value of node to be addded"<<endl;
	cin>>val;
	Node* newNode = new Node(); 
      newNode->data = val;
      newNode->next = NULL;
      newNode->pre = NULL;
      if(position < 1) {
        cout<<"\nposition should be >= 1.";
      } else if (position == 1) {
        newNode->next = head;
        head->pre = newNode;
        head = newNode;
      } else {
        Node* temp = head;
        for(int i = 1; i < position-1; i++) {
          if(temp != NULL) {
            temp = temp->next;
          }
        }
        if(temp != NULL) {
          newNode->next = temp->next;
          newNode->pre = temp;
          temp->next = newNode;
          if(newNode->next != NULL)
            newNode->next->pre = newNode;  
        } else {
          cout<<"\nThe previous node is null.";
        } 
      }

}

void doubly_list::remove_node(){
	int position;
	cout<<endl<<"Enter the postion of node to be deleted"<<endl;
	cin>>position;
	if(position < 1) {
        cout<<"\nposition should be >= 1.";
      } else if (position == 1 && head != NULL) { 
        Node* nodeToDelete = head;
        head = head->next;
        free(nodeToDelete);
        if(head != NULL)
          head->pre = NULL;
      } else {
        Node* temp = head;
        for(int i = 1; i < position-1; i++) {
          if(temp != NULL) {
            temp = temp->next;
          }
        }
        if(temp != NULL && temp->next != NULL) {
          Node* nodeToDelete = temp->next;
          temp->next = temp->next->next;
          if(temp->next->next != NULL)
            temp->next->next->pre = temp->next;  
          free(nodeToDelete); 
        } else {
          cout<<"\nThe node is already null.";
        }       
      }

}
void doubly_list::dislay(){
	ptr=head;
	while(ptr!=NULL){
		cout<<ptr->data<<"-->";
		ptr=ptr->next;
	}
	cout<<endl;
	
}
void doubly_list::displayr(){
	cout<<"list in reverse order"<<endl;
	ptr=tail;
	while(ptr!=NULL){
		cout<<ptr->data<<"-->";
		ptr=ptr->pre;
	}
}


int main(){
	doubly_list dl1;
	dl1.create();
	dl1.dislay();
	dl1.insert();
	dl1.dislay();
	dl1.remove_node();
	dl1.dislay();
	return 0;
}
