#include<iostream>
using namespace std;

class node
{
	public:
		int data;
		node *next;
		node *pre;
};
class list:public node
{
	public:
		node *head,*tail,*cur;
		node *temp;
		list()
		{
			head=NULL;
			tail=NULL;
			pre=NULL;
			cur=NULL;
		}
		void create()
	{
		int NoNode;
		cout<<"Enter the no of node"<<endl;
		cin>>NoNode;
		for(int i=0;i<=NoNode-1;i++)
		{
			
			temp=new node;
			int n;
			cout<<"Enter the values"<<endl;
			cin>>n;
			temp->data=n;
			temp->next=NULL;
			if(head==NULL) 
			{
				head=temp;
				tail=head;
			}
			else
			{
				tail->next=temp;
				tail=temp;
			}
		}
	}
	void addpos()
	{
		node *add;
		add=new node;
		int nn;
		cout<<"Enter the node"<<endl;
		cin>>nn;
		add->data=nn;
		add->next=NULL;
		int p;
		cout<<"Enter the position"<<endl;
		cin>>p;
		int count=1;
		cur=head;
		while(count!=p)
		{
			pre=cur;
			cur=cur->next;
			count++;
		}
		if(count==p)
		{
			pre->next=add;
			add->next=cur;
		}
	}
	void delpos()
	{
		int p;
		cout<<"Enter the position"<<endl;
		cin>>p;
		int count=1;
		cur=head;
		while(count!=p)
		{
			pre=cur;
			cur=cur->next;
			count++;
		}
		if(count==p)
		{
			pre->next=NULL;
			cur=cur->next;
			pre->next=cur;
		}
	}
		void display()
		{
			node * temp=head;
			
			if(temp==NULL)
			{
			cout<<"List is empty:"<<endl;
			}
			while(temp!=NULL)
			{
				cout<<temp->data;
				cout<<"---";
				temp=temp->next;
			}
			
			
		}
	
};
int main()
{
	list obj;
	cout<<"1: Create  2: Add at position 3: Delete position"<<endl;
	int ch;
	while(ch!=3)
	{
	cout<<endl<<"Enter choice:"<<endl;
	cin>>ch;
	
	switch(ch)
	{
		case 1:
			obj.create();
			cout<<"The single list is"<<endl;
			obj.display();
			break;
		case 2:
			obj.addpos();
			cout<<"Add at position"<<endl;
			obj.display();
			break;
			case 3:
				obj.delpos();
				cout<<"Delete at position"<<endl;
			obj.display();
			break;
	}
	}
}
