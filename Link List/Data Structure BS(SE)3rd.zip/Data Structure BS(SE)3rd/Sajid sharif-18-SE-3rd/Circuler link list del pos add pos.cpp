#include <iostream>
using namespace std;

class node
{
	public:
	int data;
	node*next;
	node *pre;
};
class list
{
	node *head,*last,*pre,*cur;
	node*temp;
	public:
		list()
		{
			head=NULL;
			last=NULL;
		}
			void create()
		{
			int NoNode;
			cout<<"Enter the no of node"<<endl;
			cin>>NoNode;
			for(int i=0;i<=NoNode-1;i++)
			{
				int n;
				cout<<"Enter values"<<endl;
				cin>>n;
			    temp=new node;
			    temp->data=n;
			    temp->next=NULL;
			    if(head==NULL)
			    {
				head=temp;
				last=head;
			    }
			    else
				{
					last->next=temp;
					temp->next=head;
					last=temp;
				}
			}
		}
		void addpos()
	{
		node *add;
		add=new node;
		int nn;
		cout<<"Enter the node"<<endl;
		cin>>nn;
		add->data=nn;
		add->next=NULL;
		int p;
		cout<<"Enter the position"<<endl;
		cin>>p;
		int count=1;
		cur=head;
		while(count!=p)
		{
			pre=cur;
			cur=cur->next;
			count++;
		}
		if(count==p)
		{
			pre->next=add;
			add->next=cur;
		}
	}
	void delpos()
	{
		int p;
		cout<<"Enter the position"<<endl;
		cin>>p;
		int count=1;
		cur=head;
		while(count!=p)
		{
			pre=cur;
			cur=cur->next;
			count++;
		}
		if(count==p)
		{
			pre->next=NULL;
			cur=cur->next;
			pre->next=cur;
		}
	}
		void display()
		{
			temp=head;
			if(temp==NULL)
			{
				cout<<"List is empty:"<<endl;
			}
			while(temp->next!=head)
			{
				cout<<temp->data<<"---";
				temp=temp->next;
			}
			cout<<temp->data<<endl;
		}
};

int main() {
	list obj;
	int ch;
	cout<<"1:Create  2:Add at position 3:Delete at position"<<endl;
	while(ch!=4)
{
	cout<<endl<<"Enter your choice"<<endl;
	cin>>ch;
	switch(ch)
	{
		case 1:
			obj.create();
			cout<<"The list is"<<endl;
			obj.display();
			break;
		case 2:
			obj.addpos();
			cout<<"Add at position"<<endl;
			obj.display();
			break;
		case 3:
			obj.delpos();
			cout<<"Delete at position"<<endl;
			obj.display();
			break;
	}
}
}
