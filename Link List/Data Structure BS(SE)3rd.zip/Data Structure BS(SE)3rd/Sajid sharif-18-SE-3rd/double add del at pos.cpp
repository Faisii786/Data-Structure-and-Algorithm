#include <iostream>
using namespace std;
class node
{
	public:
	int data;
	node *next;
	node *pre;
	node *cur;
};
class dlist:public node
{
		public:
		node *head, *tail, *first, *last,*previous;
		int NoNode;

		dlist()
		{
			head=NULL;
			tail=NULL;
			pre=NULL;
		}
	
		void create()
		{
			cout<<"Enter the number of node"<<endl;
			cin>>NoNode;
			for (int i=0;i<=NoNode-1;i++)
			{
			node *temp;
			temp=new node;
			int n;
			cout<<"Enter the values"<<endl;
			cin>>n;
			temp->pre=NULL;
			temp->data=n;
			temp->next=NULL;
			if(head==NULL)
			{
				head=temp;
				first=head;
				last=first;
				tail=head;
			}
			else
			{
				last->next=temp;
				temp->pre=first;
				last=temp;
				tail=temp;
			}
		}}
		void addpos()
	{
		node *add;
		node *temp;
		add=new node;
		int nn;
		cout<<"Enter the node"<<endl;
		cin>>nn;
		add->data=nn;
		add->next=NULL;
		add->pre=NULL;
		int p;
		cout<<"Enter the position"<<endl;
		cin>>p;
		int count=1;
		cur=head;
		while(count!=p)
		{
			previous=cur;
			cur=cur->next;
			count++;
		}
		if(count==p && p!=1 && p!=NoNode)
		{
			previous->next=add;
			add->pre=previous;
			add->next=cur;
			cur->pre=add;
		}
		else if(count==p && p==1 && p!=NoNode)
		{
			add->next=head;
			head->pre=add;
			add->pre=NULL;
			head=add;
		}
		else if(count==p && p!=1 && p==NoNode)
		{
			last->next=add;
			add->pre=last;
			last=add;
			last->next=NULL;
		}
		NoNode++;
	}

	void deletenode()
	{
		int count=1,pos;
		node *after;
		
		cur=first;
		while(count!=pos)
		{
			previous=cur;
			cur=cur->next;
			after=cur->next;//saving value of node next to current//
			count++;
			}
		if(count==pos && pos!=1 && pos!=NoNode)
		{
			cur->next=NULL;
			cur->pre=NULL;
			previous->next=after;//connecting previous with node next to current//
			after->pre=previous;
		}
		else if(count==pos && pos==1)
		{
			first=first->next;//2nd node became 1st//
			first->pre=NULL;
			cur->next=NULL;//1st node deleted//
			cur->pre=NULL;
			cur=first;
		}
		else if(count==pos && pos==NoNode)
		{
			previous->next=NULL;
			last->pre=NULL;
			last=previous;
			tail=last;
		}
		NoNode--;
	}
	
			void display()
			{
				node *temp=head;
				while(temp!=NULL)
				{
					cout<<temp->data;
					cout<<"--";
					temp=temp->next;
				}
			}
			void displaynn()
			{
				node *temp=tail;
				while(temp!=NULL)
				{
	 				cout<<temp->data;
					cout<<"--";
					temp=temp->pre;
				}
			}
			
};
main()
{
	dlist obj;
	int ch;
	cout<<"1: Create    2: Add at position   3: Delete at position"<<endl;
	while(ch!=3)
	{
		cout<<"Enter the choice"<<endl;
		cin>>ch;
		switch(ch)
		{
		case 1:
			obj.create();
			cout<<"The list is"<<endl;
			obj.display();
			cout<<endl;
			cout<<"The list in reverse"<<endl;
			obj.displaynn();
			cout<<endl;
			break;
		case 2:
			obj.addpos();
			cout<<"Add at position"<<endl;
			obj.display();
			cout<<endl;
			cout<<"The list in reverse"<<endl;
			obj.displaynn();
			cout<<endl;
			break;
		case 3:
			obj.deletenode();
			cout<<"Delete at position"<<endl;
			obj.display();
			cout<<endl;
			cout<<"The list in reverse"<<endl;
			obj.displaynn();
			break;
		}
	}
}
