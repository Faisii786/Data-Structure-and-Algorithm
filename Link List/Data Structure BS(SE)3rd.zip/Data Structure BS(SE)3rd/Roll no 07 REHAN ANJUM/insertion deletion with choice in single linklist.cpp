#include<iostream>
#include<conio.h>
using namespace std;
class node
{public:
	int info;
	node*next;
};
class list
{
	public:
	node*temp;
	node*first;
	node*last;
	node*current;
	node*pre;
	int size ,n,i;
	list()
	{
		first=NULL;
		last=NULL;
	}
	void add()
	{
	
	cout<<"\nEnter number of nodes you want:\n";
	cin>>size;
	for(i=0;i<size;i++)
	{
		cout<<"Enter value for node:";
		temp=new node;
		cin>>n;
		temp->info=n;
		temp->next=NULL;
		if(first==NULL)
		{
			first=temp;
			
			last=first;
		}
		else
		{
		
		last->next=temp;
		last=temp;
	
		
		}
	}
}
void add_node_choice()
{
	int count=1;
	current=first;
	int pos;
	cout<<"\nEnter location where you want to add the node:\n";
	cin>>pos;
	while(count!=pos)
	{
		pre=current;
		current=current->next;
		count++;
	}
	if(pos==1)
	{
		int a;
		cout<<"Enter value for node:";
		cin>>a;
		temp=new node;
		temp->info=a;
		temp->next=first;
		first=temp;
		
	}
	else if(pos==size)
	{
		int b;
		cout<<"Enter value for node:";
		cin>>b;
		temp=new node;
		temp->info=b;
		temp->next=NULL;
		last->next=temp;
		last=temp;
	}
	else if(count==pos)
	{
		int c;
		cout<<"Enter value for node:";
		cin>>c;
dz		temp=new node;
		temp->info=c;
		temp->next=NULL;
		pre->next=temp;
		temp->next=current;
	}
	
}
void del_node_choice()
{


    int count=1;
	current=first;
	int loc;
	cout<<"\nEnter location where you want to delete the node:\n";
	cin>>loc;
	while(count!=loc)
	{
		pre=current;
		current=current->next;
		count++;
	}
	if(loc==1)
	{
		temp=first;
		temp=temp->next;
		first=temp;
	}
	else if(count==loc)
	{
		pre->next=current->next;
		current=NULL;
		
	}
}

void display()
{
	temp=first;
	cout<<"The nodes you entere are:";
	while(temp!=NULL)
	{
		cout<<"\n"<<temp->info;
		temp=temp->next;
	}
}
};
int main()
{
	list obj;
	obj.add();
	obj.add_node_choice();
	obj.display();
	obj.del_node_choice();
	obj.display();
	getch();
	return 0;
}
