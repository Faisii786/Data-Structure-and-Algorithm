#include<bits/stdc++.h>
using namespace std;
class node
{
	public:
		int data;
		node*next;
};
class circular_linkedlist
{
	public:
		node*first,*last,*tmp;
		int i,size,n;
		circular_linkedlist()
		{
			first=NULL;
			last=NULL;
		}
		void create_node();
		void adding();
		void del();
		void display();
};
void circular_linkedlist::create_node()
{
	cout<<"Enter the number of nodes you want :"<<endl;
	cin>>size;
	for(i=1;i<=size;i++)
	{
		cout<<"Enter the value for node "<<i<<endl;
		cin>>n;
		tmp=new node;
		tmp->data=n;
		tmp->next=first;
		if(first==NULL)
		{
			first=tmp;
			last=first;
		}
		else
		{
		    last->next=tmp;
			last=tmp;
			last->next=first;
		}
	}
};
void circular_linkedlist::adding()
	{
		
			node*pre,*current,*temp;
			int y,n,pos=1;
			cout<<"enter position where you want to add node in circular linklist:"<<endl;
			cin>>y;
			cout<<"enter value in new node:"<<endl;
			cin>>n;
			pre=NULL;
    		current=first;
			temp=new node;
			temp->data=n;
			temp->next=NULL;
			
			while(pos!=y)
			{
				pre=current;
				current=current->next;
				pos++;
			}
			if(pos==y)
			{
				pre->next=temp;
				temp->next=current;
			}
			else
			{
				cout<<"value you enter is more than nodes you created:"<<endl;
			}
			
	};
	
void circular_linkedlist::del()
{
		node*pre,*current,*temp;
			int y,n,pos=1;
			cout<<"enter  node where you want to delete:"<<endl;
			cin>>y;
			pre=NULL;
    		current=first;
			
			while(pos!=y)
			{
				pre=current;
				current=current->next;
				pos++;
			}
			if(pos==y)
			{
				cout<<"Node deleted is:"<<current->data<<endl;
				pre->next=current->next;
			}
			else
			{
				cout<<"value you enter is more than nodes you created:"<<endl;
			}
};
void circular_linkedlist::display()
{
	tmp=first;
	cout<<"Nodes you entered are :"<<endl;
	while (tmp->next!=first)
	{
		cout<<tmp->data<<endl;
		tmp=tmp->next;
	}
	cout<<tmp->data<<endl;
};
int main()
{
	
	circular_linkedlist obj;
int ch;
cout<<"|===========================================|"<<endl;
cout<<"|Enter 1: To create                         |"<<endl;
cout<<"|Enter 2: To display Node                   |"<<endl;
cout<<"|Enter 3: To add node at anywhere Node      |"<<endl;
cout<<"|Enter 4: To delete node from anywhere Node |"<<endl;

cout<<"|Enter 5: To exist code                     |"<<endl;
cout<<"|===========================================|"<<endl;
while(ch!=5)
{
cout<<"       Enter your choice"<<endl;
cin>>ch;
switch(ch)
{
	

case 1:
	obj.create_node();
	break;
	case 2:
		obj.display();
	    
	    break;
	    case 3:
	    	obj.adding();
     
    
     break;
     case 4:
     	 obj.del();
     	
	
	break;
	 case 5:
     	 
     	
	
	break;
}
}
	return 0;
}

