#include<iostream>
using namespace std;
class Node
{
	public:
	int data;
	Node*next;
	Node*first;
	Node*last;
	Node*temp;
	Node*current;
	Node*pre;
	Node*tail;
	Node*previous;
	Node()
	{
		first=NULL;
		last=NULL;
	}
     int n;
		void create()
		{
			int value;
			cout<<"Enter number of nodes"<<endl;
			cin>>n;
			for(int i=0;i<n;i++)
			{
				cout<<"Enter value in node"<<endl;
				cin>>value;
			    temp=new Node;
			    temp->data=value;
			    temp->pre=NULL;
			    temp->next=NULL;
			    if(first==NULL)
			    {
				first=temp;
				last=first;
				tail=first;
			    }
			    else
			       {
				     last->next=temp;
				     temp->pre=last;
				     last=temp;	
					 tail=temp;	
			       }
			}
		}
		void displayforward()
		{
			Node*ptr=first;
			cout<<"Forward data "<<endl;
			while(ptr!=NULL)
			{
				cout<<ptr->data<<endl;
				ptr=ptr->next;
			}
		}
		void displaybackward()
		{
			Node*ptr=tail;
			cout<<"Backward data "<<endl;
			while(ptr!=NULL)
			{
				cout<<ptr->data<<endl;
				ptr=ptr->pre;
			}
		}
	void addnode()
	{
		int n,position,count=1;
		cout<<"Enter position where to add node"<<endl;
	    cin>>position;
		cout<<"Enter the value for node"<<endl;
		cin>>n;
		temp=new Node;
		temp->data=n;
		temp->next=NULL;
		temp->pre=NULL;
	    current=first;
		while(count!=position)
	    {
	    	previous=current;
	    	current=current->next;
	    	count++;
		}
		if(count==position &&position!=1)
		{
	    	previous->next=temp;
	    	temp->pre=previous;
			temp->next=current;
			current->pre=temp;
		}
		else if(count==position && position==1)
		{
			first->pre=temp;
			temp->next=first;
			temp->pre=NULL;
			first=temp;
		}
		else if(count==position&& position==n)
		{
			last->next=temp;
			temp->pre=last;
			temp->next=NULL;
			last=temp;
			tail=temp;
		}
		else
		{
			cout<<"Node addition failed."<<endl;
		}
	}
   void deletenode()
	{
		int count=1,pos;
		cout<<"Enter location to delete node :"<<endl;
	    cin>>pos;
		current=first;
		while(count!=pos)
		{
			previous=current;
			current=current->next;
			count++;
			}
		if(count==pos && pos==1)
		{
			first=first->next;
			first->pre=NULL;
			current->next=NULL;
			current->pre=NULL;
			current=first;
		}
		else if(count==pos && pos!=1 &&pos!=n)
		{
			previous->next=current->next;
			current=current->next;
			current->pre=previous;
		}
		else if(count==pos && pos==n)
		{
			previous->next=NULL;
			current->pre=NULL;
			last=previous;
			tail=last;
		}
	}
};
int main()
{
	Node N;
	int ch;
	cout<<"1-enter 1:Create\n2-To Enter 2 : To Display forward\n3- To Enter 3: To Display backward\n4- To Enter 4:To Add\n5- enter 5:To Delete\n6- Enter 6: To Exit"<<endl;
	while(ch!=6)
	{
		cout<<"========================="<<endl;
	cout<<"Enter your choice :"<<endl;
	cin>>ch;
	switch(ch)
	{
		case 1:
			N.create();
			break;
			case 2:
				N.displayforward();
				break;
				case 3:
					N.displaybackward();
					break;
					case 4:
				    	N.addnode();
						break;
						case 5:
							N.deletenode();
							break;
	}
}
	return 0;
}


