#include<iostream>
using namespace std;
class node
{
	public:
	int info;
	node*first,*next,*last,*temp,*previous,*current;
	node()
	{
		first=NULL;
		last=NULL;
		current=NULL;
		previous=NULL;
	}
	void create()
	{
	    int numnode,size;
		cout<<"Enter the size of the circular linklist"<<endl;
		cin>>size;
		for(int i=0;i<size;i++)
		{
			cout<<"Enter the value"<<endl;
			cin>>numnode;
		    temp=new node;
		    temp->info=numnode;
		    temp->next=NULL;
		    if(first==NULL)
		    {
		 	 first=temp;
			 last=first;
			}
		    else
			{
			 last->next=temp;
			 last=temp;		
		    }
		}
	}
	void display()
	{
		node*temp=first;
		cout<<"Information of the  circular linklist"<<endl;
		if(temp==NULL)
		{
			cout<<"List is empty:"<<endl;
		}
		while(temp!=NULL)
		{
			cout<<temp->info<<endl;
			temp=temp->next;
		}
	}
	void insertnode()
	{
		int y,position,count=1;
		cout<<"Enter adding position of node"<<endl;
	    cin>>position;
		cout<<"Enter the value for node"<<endl;
		cin>>y;
		temp=new node;
		temp->info=y;
		temp->next=NULL;
	    current=first;
		while(count!=position)
	    {
	    	previous=current;
	    	current=current->next;
	    	count++;
		}
		if(count==position &&position==1)
		{
			temp->next=first;
			first=temp;
		}
		if(count==position)
		{
	    	previous->next=temp;
			temp->next=current;
		}
		else
		{
			cout<<"Unable to insert the  node"<<endl;
		}
	   }
   void deletenode()
	{
		int count=1,position;
		cout<<"Enter node number which you want to delete node"<<endl;
	    cin>>position;
		current=first;
		while(count!=position)
		{
			previous=current;
			current=current->next;
			count++;
			}
		if(position==1)
		{
			current->next=NULL;
			first=first->next;
			current=first;
		}
		if(count==position)
		{
			previous->next=current->next;
			current=NULL;
		}
	}
};
int main()
{
	node obj;
	int choice;
	cout<<"1-Create\n2-insert node\n3-Display linklist\n4-Delete node\n5-Exit"<<endl;
	while(choice!=5)
	{
	cout<<"Enter your  choice "<<endl;
	cin>>choice;
	switch(choice)
	{
		case 1:
			obj.create();
			break;
			case 2:
			obj.insertnode();
				break;
				case 3:
				obj.display();
					break;
					case 4:
				    	obj.deletenode();
						break;
	}
}
	return 0;
}


