#include<iostream>
using namespace std;
class Node
{
	public:
	int data;
	Node*next;
	Node*first;
	Node*head;
	Node*pre;
	Node*ptr;
	Node*tail;
	Node*current;
	Node*previous;
	Node*newnode;
	Node*temp;
};
	class linklistd:public Node
	{
	public:
		linklistd()
		{
			first=NULL;
			head=NULL;
			current=NULL;
			previous=NULL;
			tail=NULL;
			newnode=NULL;
		}
		void create()
		{
			int num,size;
			cout<<"Enter size of linklist"<<endl;
			cin>>size;
			for(int ii=0;ii<size;ii++)
			{
				cout<<"Enter value"<<endl;
				cin>>num;
			    newnode=new Node;
			    newnode->data=num;
			    newnode->pre=NULL;
			    newnode->next=NULL;
			    if(head==NULL)
			    {
				head=newnode;
				first=head;
				tail=head;
			    }
			    else
			       {
				     first->next=newnode;
				     newnode->pre=first;
				     first=newnode;	
					 tail=newnode;	
			       }
			}
		}
		void adding()
	{
		
		
			int z,n,pos=1;
			cout<<"enter position where you want to add node in circular linklist:"<<endl;
			cin>>z;
			cout<<"enter value in new node:"<<endl;
			cin>>n;
			previous=NULL;
    		current=first;
			temp=new Node;
			temp->data=n;
			temp->next=NULL;
			
			while(pos!=z)
			{
				previous=current;
				current=current->next;
				pos++;
			}
			if(pos==z)
			{
				previous->next=temp;
				temp->next=current;
			}
			else
			{
				cout<<"value you enter is more than nodes you created:"<<endl;
			}
			
	}
	
void del()
{
	
			int z,n,pos=1;
			cout<<"enter  node where you want to delete:"<<endl;
			cin>>z;
			previous=NULL;
    		current=first;
			
			while(pos!=z)
			{
				previous=current;
				current=current->next;
				pos++;
			}
			if(pos==z)
			{
				cout<<"Node deleted is:"<<current->data<<endl;
				previous->next=current->next;
			}
			else
			{
				cout<<"value you enter is more than nodes you created:"<<endl;
			}
}
void display()
{
	temp=first;
	cout<<"Nodes you entered are :"<<endl;
	while (temp->next!=first)
	{
		cout<<temp->data<<endl;
		temp=temp->next;
	}
	cout<<temp->data<<endl;
}
};
int main()
{
		linklistd ob;
	cout<<" creating nodes"<<endl;
	ob.create();
	cout<<"Adding nodes"<<endl;
     ob.adding();
     cout<<"Deleting nodes"<<endl;
     ob.del();
     cout<<"Displaying nodes"<<endl;
	ob.display();
	return 0;
}

