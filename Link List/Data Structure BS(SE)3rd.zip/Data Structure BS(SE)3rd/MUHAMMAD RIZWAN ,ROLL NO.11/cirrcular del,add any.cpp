#include<iostream>
#include<conio.h>
using namespace std;
class node
{
	public:
		int data;
		node*next;
};
class linklist:public node
{
	
		public:
		node*first,*last,*tmp;
		int i,size,n;
		public:
		circular_linkedlist()
		{
			first=NULL;
			last=NULL;
		}
		void create()
		{
			int num,size;
			cout<<"Enter size of linklist"<<endl;
			cin>>size;
			for(int ii=0;ii<size;ii++)
			{
				cout<<"Enter value"<<endl;
				cin>>num;
			    tmp=new node;
			    tmp->data=num;
			    tmp->next=NULL;
			    if(first==NULL)
			    {
				first=tmp;
				last=first;
			    }
			    else
			       {
				     last->next=tmp;
				     last=tmp;		
			       }
			}
	
		


}
void adding()
	{
		
			node*previous,*current,*temp;
			int z,n,pos=1;
			cout<<"enter position where you want to add node in circular linklist:"<<endl;
			cin>>z;
			cout<<"enter value in new node:"<<endl;
			cin>>n;
			previous=NULL;
    		current=first;
			temp=new node;
			temp->data=n;
			temp->next=NULL;
			
			while(pos!=z)
			{
				previous=current;
				current=current->next;
				pos++;
			}
			if(pos==z)
			{
				previous->next=temp;
				temp->next=current;
			}
			else
			{
				cout<<"value you enter is more than nodes you created:"<<endl;
			}
			
	};
	
void del()
{
		node*previous,*current,*temp;
			int z,n,pos=1;
			cout<<"enter  node where you want to delete:"<<endl;
			cin>>z;
			previous=NULL;
    		current=first;
			
			while(pos!=z)
			{
				previous=current;
				current=current->next;
				pos++;
			}
			if(pos==z)
			{
				cout<<"Node deleted is:"<<current->data<<endl;
				previous->next=current->next;
			}
			else
			{
				cout<<"value you enter is more than nodes you created:"<<endl;
			}
};
void display()
{
	tmp=first;
	cout<<"Nodes you entered are :"<<endl;
	while (tmp->next!=first)
	{
		cout<<tmp->data<<endl;
		tmp=tmp->next;
	}
	cout<<tmp->data<<endl;
}
};
int main()
{
	linklist ob;
	cout<<" creating nodes"<<endl;
	ob.create();
	cout<<"Adding nodes"<<endl;
     ob.adding();
     cout<<"Deleting nodes"<<endl;
     ob.del();
     cout<<"Displaying nodes"<<endl;
	ob.display();
	return 0;
}

